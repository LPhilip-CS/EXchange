//
//  ViewController.swift
//  CurrencyCalculator
//
//  Created by ONS on 20/04/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var lblResult: UILabel!//For testing only
    
    private let apiPath = "https://open.er-api.com/v6/latest/USD"
    private var currentExchangeRates: CurrentExchangeRates?
    private var totalCoin: Double = 1 //For testing only
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getCurrentExchangeRates()
    }
    
    private func getCurrentExchangeRates() {
        guard let url = URL(string: apiPath) else {
            return
        }
        
        URLSession.shared.dataTask(with:url) { (data, response, error) in
            guard error == nil else {
                print(error ?? "Something went wrong!!")
                return
            }
            
            guard let data = data else {
                return
            }
            
            do {
                let decoder = JSONDecoder()
                self.currentExchangeRates = try decoder.decode(CurrentExchangeRates.self, from: data)
            } catch {
                print(error)
            }
        }.resume()
    }
    
    private func getUSDValueFrom(currencyType: String?, value: Double?) -> Double? {
        guard let currencyType = currencyType?.uppercased(),
                let value = value,
                let currentExchangeRates = currentExchangeRates,
                let allCurrencyTypes = currentExchangeRates.rates,
                let exchangeRate = allCurrencyTypes[currencyType] else {
            return nil
        }
        
        return value * exchangeRate
    }
    
    //For testing only
    @IBAction func didClickOnTesting() {
        let testingCurrencyType = "EUR"
        guard let usdValue =  getUSDValueFrom(currencyType: testingCurrencyType, value: totalCoin) else {
            lblResult.text = "Result USD value is nil"
            return
        }
        
        lblResult.text = "Result USD value for \(totalCoin) is -> \(usdValue)"
        totalCoin += 1
    }
}

