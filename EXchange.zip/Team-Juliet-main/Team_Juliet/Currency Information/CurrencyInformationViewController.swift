//
//  CurrencyInformationViewController.swift
//  Team_Juliet
//
//  Created by Lijo Philip on 3/30/22.
//

import UIKit

class CurrencyInformationViewController: UIViewController {
    
    // Elements in the currency information VC.
    @IBOutlet weak var currencyNameLabel: UILabel!
    
    @IBOutlet weak var currencyImageView: UIImageView!
    
    @IBOutlet weak var currencyFlagImageView: UIImageView!
    
    @IBOutlet weak var currencyInfoLabel: UILabel!
    
    
    var currencyName = ""
    var currencyImage = UIImage()
    var currencyFlag = UIImage()
    var currencyInfo = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        currencyNameLabel.text = currencyName
        currencyImageView.image = currencyImage
        currencyFlagImageView.image = currencyFlag
        currencyInfoLabel.text = currencyInfo

        // Do any additional setup after loading the view.
    }
    
    
    


}
