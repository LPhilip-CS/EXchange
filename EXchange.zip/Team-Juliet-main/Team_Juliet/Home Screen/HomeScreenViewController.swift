//
//  HomeScreenViewController.swift
//  Team_Juliet
//
//  Created by Lijo Philip on 3/22/22.
//

import UIKit
import FirebaseAuth

class HomeScreenViewController: UIViewController {
    
    @IBAction func unwindToHomeScreen(segue: UIStoryboardSegue) {
        
    }
    
    // Go back to homescreen.
    @IBOutlet weak var signOutLabel: UILabel!
    
    var signedId : (() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.setupSignOut()
    }
    
    @objc func signOut(_ sender: UITapGestureRecognizer) {
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
            signedId!()
        } catch let signOutError as NSError {
          print("Error signing out: %@", signOutError)
        }
    }
    
    // Function to sign out of app.
    func setupSignOut() {
        
        let labelTap = UITapGestureRecognizer(target: self, action: #selector(self.signOut(_:)))
        self.signOutLabel.isUserInteractionEnabled = true
        self.signOutLabel.addGestureRecognizer(labelTap)
    }
    
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//
//    }
    

}
