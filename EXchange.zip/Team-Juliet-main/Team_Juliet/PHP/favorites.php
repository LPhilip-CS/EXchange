<?php

include('queryFunctions.php');

$desired_endpoint = $_GET['endpoint'];


switch ($desired_endpoint) {
    case 'upload':
        $user_id = $_GET['user_id'];
        $currency = $_GET['currency'];

        echo json_encode(
            uploadFavorite($user_id, $currency)
        );
        break;
    case 'get':
        $user_id = $_GET['user_id'];
        echo json_encode(
                getAllFavoritesByUserId($user_id)
        );
        break;
    default:
        echo json_encode(['error' => 'Invalid endpoint']);
        break;
}
