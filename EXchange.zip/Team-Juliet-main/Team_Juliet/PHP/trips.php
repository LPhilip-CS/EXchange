<?php

include('queryFunctions.php');

$desired_endpoint = $_GET['endpoint'];


switch ($desired_endpoint) {
    case 'uploadTrip':
        $user_id = $_GET['user_id'];

        echo json_encode(
            ["trip_id" => uploadTrip($user_id,)]
        );
        break;
    case 'uploadTripTracker':
        $user_id = $_GET['user_id'];
        $trip_id = $_GET['trip_id'];
        $date = $_GET['date'];
        $amount = $_GET['amount'];
        $currency = $_GET['currency'];

        echo json_encode(
            ["message" => uploadTripTracker($user_id, $trip_id, $currency, $amount, $date)]
        );
        break;
    case 'getTrips':
        $user_id = $_GET['user_id'];
        echo json_encode(
                getAllTripsByUserId($user_id)
        );
        break;
    case 'getTripTrackers':
        $trip_id = $_GET['trip_id'];
        echo json_encode(
                getAllTripTrackersByTripId($trip_id)
        );
        break;
    
    default:
        echo json_encode(['error' => 'Invalid endpoint']);
        break;
}
