<?php

require_once('dbsetup.php');

// ============================================================================
// Retrieve Data
// ============================================================================

/**
 * Retrieve all favorites for a user
 */
function getAllFavoritesByUserId($user_id)
{
    $sql = "SELECT * FROM favorites WHERE favorites.user_id = '$user_id'";
    $result = mysqli_query(getDB(), $sql);

    if (mysqli_num_rows($result) > 0) {
        $favorites = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $favorites[] = $row;
        }
        return $favorites;
    } else {
        return [];
    }
}

/**
 * Retrieve all trips for a user
 */
function getAllTripsByUserId($user_id)
{
    $sql = "SELECT * FROM trips WHERE user_id = '$user_id'";
    $result = mysqli_query(getDB(), $sql);

    if (mysqli_num_rows($result) > 0) {
        $trips = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $trips[] = $row;
        }
        return $trips;
    } else {
        return [];
    }
}

/**
 * Retrieve all transactions for a trip
 */
function getAllTripTrackersByTripId($trip_id)
{
    $sql = "SELECT * FROM trip_tracker WHERE trip_id = '$trip_id' ORDER BY date DESC";
    $result = mysqli_query(getDB(), $sql);

    if (mysqli_num_rows($result) > 0) {
        $trip_trackers = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $trip_trackers[] = $row;
        }
        return $trip_trackers;
    } else {
        return [];
    }
}


// ============================================================================
// Insert Data
// ============================================================================

function uploadFavorite(string $userId, string $currency)
{
    $sql = "INSERT INTO favorites (user_id, currency) VALUES ('$userId', '$currency')";
    if (mysqli_query(getDB(), $sql)) {
        return ['success' => true];
    } else {
        return [
            'success' => false,
            'sql' => $sql,
            'error' => mysqli_error(getDB())
        ];
    }
}

function uploadTrip($user_id)
{
    $sql = "INSERT INTO trips (user_id) VALUES ('$user_id')";
    if (mysqli_query(getDB(), $sql)) {
        return mysqli_insert_id(getDB());
    } else {
        return false;
    }
}

function uploadTripTracker($user_id, $trip_id, $currency, $amount, $date)
{
    $formattedDate = date('Y-m-d', strtotime($date));

    $sql = "INSERT INTO trip_tracker (user_id, trip_id, currency, amount, date) VALUES ('$user_id', '$trip_id', '$currency', '$amount', '$formattedDate')";
    if (mysqli_query(getDB(), $sql)) {
        return true;
    } else {
        return mysqli_error(getDB());
    }
}
