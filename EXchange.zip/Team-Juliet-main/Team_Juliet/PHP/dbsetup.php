<?php

$dbhost = 'cs.okstate.edu';
$dbuser = 'ayking';
$dbpass = '<indLeopard18';
$dbname = 'MAD_Spr22_Juliet';

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

if (!$conn) {
    die('Could not connect: ' );
}

function getDB() {
    global $conn;
    return $conn;
}
