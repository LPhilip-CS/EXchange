//
//  AuthTextFieldStyle.swift
//  Team_Juliet
//
//  Created by Ayren King on 3/7/22.
//

import SwiftUI

struct AuthTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding()
            .background(Color( red: 234/255, green: 234/255, blue: 234/255, opacity: 0.5))
            .cornerRadius(20)
            .overlay(RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.gray,lineWidth: 1.5))
            .shadow(radius: 10)
    }
}
