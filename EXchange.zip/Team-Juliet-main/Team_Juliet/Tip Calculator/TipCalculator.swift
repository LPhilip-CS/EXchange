//
//  TipCalculator.swift
//  Team_Juliet
//
//  Created by Lijo Philip on 2/23/22.
//

import Foundation

class TipCalculator {
    
    var billAmount: Double = 0
    var tipAmount: Double = 0
    var tipPercentage: Double = 0
    var totalAmount: Double = 0
    
    
    init(billAmount: Double, tipPercentage: Double) {
        
        self.billAmount = billAmount
        self.tipPercentage = tipPercentage
    }
    
    // Calculated tipped amount and total amount.
    func calculateTip() {
        tipAmount = billAmount * tipPercentage
        totalAmount = tipAmount + billAmount
    }
    
}
