//
//  ExchnageRates.swift
//  Team_Juliet
//
//  Created by Lijo Philip on 3/9/22.
//

// Exchange API object.
import Foundation

struct ExchangeRates: Codable {
    let rates: [String: Double]
}
