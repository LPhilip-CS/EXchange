//
//  ViewController.swift
//  Ex Change
//
//  Created by Lijo Philip on 2/23/22.
//

import UIKit

class TipCalculatorViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    // UI elements for tip calculator.
    @IBOutlet weak var totalAmount: UILabel!
    @IBOutlet weak var eachPersonAmount: UILabel!
    
    @IBOutlet weak var billAmountTextField: UITextField!
   
    @IBOutlet weak var tipLabel: UILabel!
    @IBOutlet weak var tipSlider: UISlider!
    
    @IBOutlet weak var splitLabel: UILabel!
    @IBOutlet weak var splitSlider: UISlider!
    
    
    @IBOutlet weak var currExchnageLabel: UILabel!
    @IBOutlet weak var currExchangePicker: UIPickerView!
    
    
    // MARK: - Properties
    var tipCalculator = TipCalculator(billAmount: 0, tipPercentage: 0.10)
    var currencyCode: [String] = []
    var values: [Double] = []
    var selectedCurrency = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        currExchangePicker.delegate = self
        currExchangePicker.dataSource = self
        fetchJSON()
        
        billAmountTextField.addTarget(self, action: #selector(updateViews), for: .editingChanged)
        
        
    }

    
    // Calculate bill amount with tip.
    func calculateBill() {
        tipCalculator.tipPercentage = Double(tipSlider.value) / 100.0
        tipCalculator.billAmount = (billAmountTextField.text! as NSString).doubleValue
        tipCalculator.calculateTip()
        updateUI()
        
    }
    
    
    // Update UI with new inputs.
    func updateUI() {
        totalAmount.text = String(format: "%0.2f", tipCalculator.totalAmount)
        let numberOfPeople: Int = Int(splitSlider.value)
        eachPersonAmount.text = String(format: "%0.2f", tipCalculator.totalAmount / Double(numberOfPeople))
    }
    
    // Calculate the bill amount.
    @IBAction func billAmount(sender: Any) {
        calculateBill()
    }
    
    // Change tip percentage.
    @IBAction func tipPercentage(sender: Any) {
        tipLabel.text = String(format: " Tip: %01d%%", Int(tipSlider.value))
        calculateBill()
        
    }
    
    // Change split per person.
    @IBAction func splitPerPerson(sender: Any) {
        splitLabel.text = "Split: \(Int(splitSlider.value))"
        calculateBill()
        
    }
    
    // Converting bill amount to various currencies.
    @objc func updateViews(input: Double) {
        guard let amountText = billAmountTextField.text, let theAmountText = Double(amountText) else { return }
        if billAmountTextField.text != "" {
            let total = theAmountText * selectedCurrency
            currExchnageLabel.text = String(format: "%.2f", total)
        }
    }
    
    // MARK - Get JSON Data
    func fetchJSON() {
        guard let url = URL(string: "https://open.er-api.com/v6/latest/USD") else { return }
        URLSession.shared.dataTask(with:url) { (data, response, error) in
            
            // Error handling
            if error != nil {
                print(error!)
                return
            }
            
            // Unwrap the data
            guard let safeData = data else { return }
            
            // Decoce JSON data
            do {
                let results = try JSONDecoder().decode(ExchangeRates.self, from: safeData)
                self.currencyCode.append(contentsOf: results.rates.keys)
                self.values.append(contentsOf: results.rates.values)
                DispatchQueue.main.async {
                    self.currExchangePicker.reloadAllComponents()
                }
                
            }catch {
                print(error)
            }
        }
        .resume()
        
        
    }
    
    // Implementing pickerview to display all currencies.
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return currencyCode.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return currencyCode[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedCurrency = values[row]
        updateViews(input: selectedCurrency)
    }
    
}

