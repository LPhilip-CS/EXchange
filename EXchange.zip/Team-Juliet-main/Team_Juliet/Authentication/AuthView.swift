//
//  AuthView.swift
//  Team_Juliet
//
//  Created by Ayren King on 3/7/22.
//

import SwiftUI

struct AuthView: View {
    
    
    @State var isSignedIn : Bool = UserViewModel().isSignedIn
    @State var isLoading : Bool = false
    
    func updateSignedIn() { isSignedIn = !isSignedIn }
    
    func updateLoading() { isLoading = !isLoading }
    
    var body: some View {
        if isLoading {
            AuthLoadingView()
        } else {
            
            if isSignedIn {
                MainWrapper(signedId: updateSignedIn).ignoresSafeArea()
            }
            else {
                LoginView(signedId: updateSignedIn, updateLoading: updateLoading)
            }
        }
    }
}

struct AuthView_Previews: PreviewProvider {
    static var previews: some View {
        AuthView()
    }
}
