//
//  LoginView.swift
//  Team_Juliet
//
//  Created by Ayren King on 3/7/22.
//

import SwiftUI

struct LoginView: View {
    
    var signedId : (() -> Void)?
    var updateLoading : (() -> Void)?
    
    @State var email = ""
    @State var password = ""
    @State var loading = false
    
    var body: some View {
        NavigationView {
            ZStack {
                
                LinearGradient(gradient: Gradient(colors: [
                    Color( red: 177/255, green: 255/255, blue: 150/255, opacity: 0.5),
                    Color.white
                ]), startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea(.all)
                
                
                VStack {
                    
                    Text("Welcome...")
                        .font(.system(size: 36))
                        .foregroundColor(Color(red: 130/255, green: 130/255, blue: 130/255))
                    
                    Image("auth_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 200)
                    
                    VStack(alignment: .trailing) {
                        TextField("Email Address", text: $email)
                            .padding()
                            .textFieldStyle(AuthTextFieldStyle())
                        
                        SecureField("Password", text: $password)
                            .padding()
                            .textFieldStyle(AuthTextFieldStyle())
                        
                        Button(action: {
                            
                            // Switch to Reseting Password
                            
                        }, label: {
                            Text("Forgot Password")
                                .foregroundColor(Color(red: 40/255, green: 202/255, blue: 37/255))
                                .font(.system(size: 18, weight: .heavy))
                                .padding(.trailing)
                            
                        })
                    }
                    .padding()
                    
                    
                    
                    Spacer()
                    
                    Button(action:{
                        
                        guard !email.isEmpty, !password.isEmpty else {
                            return
                        }
                        
                        Task {
                            updateLoading!()
                            let user = await UserViewModel().signIn(email: email, password: password)
                            updateLoading!()
                            
                            if user == nil {
                                email = ""
                                password = ""
                                
                                print("Log in not successful")
                                return
                            }
                            
                            print("Navigate to first screen")
                            signedId!()
                        }
                    }, label: {
                        Text("Login")
                            .frame(width: 200, height: 50)
                            .background(Color(red: 40/255, green: 202/255, blue: 37/255, opacity: 0.5))
                            .foregroundColor(Color.white)
                            .font(.system(size: 18))
                    }).cornerRadius(12.5)
                    
                    HStack {
                        Text("Don't have an account?")
                            .font(.system(size: 20))
                            .foregroundColor(Color(red: 130/255, green: 130/255, blue: 130/255))
                        
                        NavigationLink(destination: RegisterView(signedId: signedId, updateLoading: updateLoading)) {
                            Text("Sign up")
                                .foregroundColor(Color(red: 40/255, green: 202/255, blue: 37/255))
                                .font(.system(size: 20, weight: .heavy))
                        }
                        
                    }
                }
            }
        }
    }
    
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
