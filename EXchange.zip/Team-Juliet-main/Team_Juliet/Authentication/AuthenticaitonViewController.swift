//
//  AuthenticaitonViewController.swift
//  Team_Juliet
//
//  Created by Ayren King on 3/7/22.
//

import UIKit
import SwiftUI

class AuthenticaitonViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let childView = UIHostingController(rootView: AuthView())
        addChild(childView)
        childView.view.frame = view.bounds
        view.addSubview(childView.view)
        childView.didMove(toParent: self)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
