//
//  MainWrapper.swift
//  Team_Juliet
//
//  Created by Ayren King on 3/9/22.
//

import SwiftUI

struct MainWrapper : UIViewControllerRepresentable {
    
    var signedId : (() -> Void)?
    
    func makeUIViewController(context: Context) -> HomeScreenViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        guard let viewController = storyboard.instantiateViewController(withIdentifier: "main_board") as? HomeScreenViewController else {
            fatalError("Cannot load from storyboard")
        }
        
        
        viewController.signedId = signedId
        return viewController
        
    }
    
    func updateUIViewController(_ uiViewController: HomeScreenViewController, context: Context) {
        
    }
}
