//
//  AuthSegue.swift
//  Team_Juliet
//
//  Created by Ayren King on 3/28/22.
//

import Foundation
import UIKit

class AuthSegue : UIStoryboardSegue {
    override func perform() {        if let navigationController = self.source.navigationController {
            navigationController.setViewControllers([self.destination], animated: true)
        }
    }
}
