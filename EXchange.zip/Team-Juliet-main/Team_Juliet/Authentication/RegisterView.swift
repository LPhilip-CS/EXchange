//
//  RegisterView.swift
//  Team_Juliet
//
//  Created by Ayren King on 3/7/22.
//

import SwiftUI

struct RegisterView: View {
    
    var signedId : (() -> Void)?
    var updateLoading : (() -> Void)?
    
    @Environment(\.dismiss) var dismiss
    
    @State var email = ""
    @State var password = ""
    
    var body: some View {
        ZStack {
            
            LinearGradient(gradient: Gradient(colors: [
                Color( red: 177/255, green: 255/255, blue: 150/255, opacity: 0.5),
                Color.white
            ]), startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea(.all)
            
            
            VStack {
                
                Text("Register")
                    .font(.system(size: 36))
                    .foregroundColor(Color(red: 130/255, green: 130/255, blue: 130/255))
                
                Image("register_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 200, height: 200)
                
                VStack(alignment: .trailing) {
                    TextField("Email Address", text: $email)
                        .padding()
                        .textFieldStyle(AuthTextFieldStyle())
                    
                    SecureField("Password", text: $password)
                        .padding()
                        .textFieldStyle(AuthTextFieldStyle())
                    
                    
                }
                .padding()
                
                Image("firebase_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150)
                
                Spacer()
                
                Button(action: {
                    
                    guard !email.isEmpty, !password.isEmpty else {
                        return
                    }
                    
                    Task {
                        updateLoading!()
                        let user = await UserViewModel().signUp(email: email, password: password)
                        updateLoading!()
                        
                        if user == nil {
                            email = ""
                            password = ""
                            
                            print("Register not successful")
                            return
                        }
                        print("Navigate to first screen")
                        signedId!()
                    }
                    
                }, label: {
                    Text("Submit")
                        .frame(width: 200, height: 50)
                        .background(Color(red: 40/255, green: 202/255, blue: 37/255, opacity: 0.5))
                        .foregroundColor(Color.white)
                        .font(.system(size: 18))
                }).padding().cornerRadius(12.5)
                
                HStack {
                    Text("Have an account?")
                        .font(.system(size: 20))
                        .foregroundColor(Color(red: 130/255, green: 130/255, blue: 130/255))
                    Button(action: {
                        dismiss.callAsFunction()
                        
                    }, label: {
                        Text("Login here")
                            .foregroundColor(Color(red: 40/255, green: 202/255, blue: 37/255))
                            .font(.system(size: 20, weight: .heavy))
                    })
                }
            }
        }
    }
    
}

struct RegisterView_Previews: PreviewProvider {
    static var previews: some View {
        RegisterView()
    }
}
