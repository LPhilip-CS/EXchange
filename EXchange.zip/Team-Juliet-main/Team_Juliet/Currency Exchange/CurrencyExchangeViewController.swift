//
//  CurrencyExchangeViewController.swift
//  Team_Juliet
//
//  Created by Isabell Cook on 4/17/22.
//

import UIKit
import Charts

class CurrencyExchangeViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource  {

    /**
     Structure used to decode History API
     */
    struct historyJson: Decodable {
        var result: String
        var documentation: String
        var terms_of_use: String
        var year: Int
        var month: Int
        var day: Int
        var base_code: String
        var conversion_rates: [String: Double]
    }
    
    /**
     Variable used to access each currencies (String) history conversion via a dictionary contning year:conversion rate values
     */
    var historyRates: [String : [Int: Double]] = [:]
    /**
     String of currencies that the API provides history for
     */
    var historyCurrency: [String] = []
    
    // Currency selected by the picker selector
    var selectedCurrency1: String = ""
    var selectedCurrency2: String = ""


    // UITextField outlets
    @IBOutlet weak var Amount1TextField: UITextField!
    @IBOutlet weak var Amount2TextField: UITextField!

    // UIPickerView outlets
    @IBOutlet weak var currencyPicker1: UIPickerView!
    @IBOutlet weak var currencyPicker2: UIPickerView!
    
    // LineChartView Outlet
    @IBOutlet weak var LineChartView: LineChartView!
    
    // Oulets for spinner application
    @IBOutlet weak var SpinnerView: UIView!
    @IBOutlet weak var Spinner: UIActivityIndicatorView!
    @IBOutlet var MainView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        showSpinnerView()
        selectedCurrency1 = ""
        selectedCurrency2 = ""
        currencyPicker1.delegate = self
        currencyPicker1.dataSource = self
        currencyPicker2.delegate = self
        currencyPicker2.dataSource = self
        generateHistoryOfCurrencies()
    }
    
    
    // MARK: - Historical Currency Set Up
    
    /**
     Arguments: NULL
     Return: NULL
     Description:
         Calls API accessor method for range of years 1990 - 2022. Accesses API every two years.
     */
    func generateHistoryOfCurrencies() {
        var year = 1990
        while year <= 2020 {
            getHistoricalCurrencyForYear(year: year, last: false)
            year += 2
        }
        getHistoricalCurrencyForYear(year: 2022, last: true)
    }
    
    /**
     Argument: year: Int
     Argument: last: Bool
     Return: NULL
     Description:
         Accesses data from history API on the first of january for the year indicated
         Saves data to historyRates.
         Resets pickerView values
         Hides spinner view
     */
    func getHistoricalCurrencyForYear(year: Int, last: Bool) {
        // Get API URL and start URL session
        guard let url = URL(string: "https://v6.exchangerate-api.com/v6/0345f32d201eb0a05347727c/history/USD/\(year)/1/1") else { return }
        URLSession.shared.dataTask(with:url) { (data, response, error) in
            // Define variables
            var currencyCode: [String] = []
            var values: [Double] = []

            // Error handling
            if error != nil {
                print(error!)
                return
            }
            // Unwrap the data
            guard let safeData = data else { return }
            // Decoce JSON data
            do {
                // Parse data from JSON
                let results = try JSONDecoder().decode(historyJson.self, from: safeData)
                currencyCode.append(contentsOf: results.conversion_rates.keys)
                values.append(contentsOf: results.conversion_rates.values)

                // Add parsed Data to historyRates
                for (index, currency) in currencyCode.enumerated() {
                    let temp = [year: values[index]]
                    if self.historyRates[currency] != nil {
                        self.historyRates[currency]?[year] = values[index]
                    } else {
                        self.historyRates[currency] = temp
                    }
                }
                
                // When it is the last call to the API set needed data
                if last {
                    DispatchQueue.main.async {
                        self.historyCurrency = Array(self.historyRates.keys)
                        self.historyCurrency.sort()
                        self.currencyPicker1.reloadAllComponents()
                        self.currencyPicker2.reloadAllComponents()
                        self.hideSpinner()
                    }
                }
            }catch {
                print(error)
            }
        }
        .resume()
    }
    
    
    // MARK: - Line Graph
    
    /**
     Arguments: NULL
     Return: NULL
     Description:
         Uses historyRates, selectedCurrency1 & 2, and LineGraphView to set data to the lineGraphView
     */
    func setGraphView() {
        // Get data for selectedCurrency1
        let yearRates1: [Int: Double] = historyRates[selectedCurrency1]!
        let sortedYears1 : [Int] = yearRates1.keys.sorted(by: <)
        var values1: [ChartDataEntry] = []
        
        // Set values1 aka data entries for currency 1 for all years applicable
        for year in sortedYears1 {
            let rate = Double(Amount1TextField.text ?? "1") ?? 1 * yearRates1[year]!
            values1.append(ChartDataEntry(x: Double(year), y: rate))
        }
        
        // Get data for selectedCurrency2
        let yearRates2: [Int: Double] = historyRates[selectedCurrency2]!
        let sortedYears2: [Int] = yearRates2.keys.sorted(by: <)
        var values2: [ChartDataEntry] = []
        
        // Set values2 aka data entries for currency 1 for all years applicable
        for year in sortedYears2 {
            let rate = Double(Amount2TextField.text ?? "1") ?? 1 * yearRates2[year]!
            values2.append(ChartDataEntry(x: Double(year), y: rate))
        }
            
        // Define the data sets for each currency
        let set1 = LineChartDataSet(entries: values1, label: selectedCurrency1)
        let set2 = LineChartDataSet(entries: values2, label: selectedCurrency2)
            
        // Define data set preferences for graph
        set1.colors = [UIColor.systemRed]
        set1.circleHoleColor = UIColor.systemRed
        set2.colors = [UIColor.systemBlue]
        set2.circleHoleColor = UIColor.systemBlue
            
        // Define Chart data
        let data = LineChartData(dataSets: [set1, set2])
            
        // Define Graph preferences
        LineChartView.rightAxis.enabled = false
        LineChartView.xAxis.labelPosition = .bottom
        
        //Plot Graph
        self.LineChartView.data = data
    }
    
    
    // MARK: - Spinner
    
    /**
     Arguments: NULL
     Return: NULL
     Description:
         Opens up the view that contains the spinner. Shows and animates the spinner.
     */
    func showSpinnerView() {
        // Open View
        SpinnerView.frame = self.view.safeAreaLayoutGuide.layoutFrame
        
        // animate spinner
        Spinner.startAnimating()
        
        // Add spinner to view
        SpinnerView.addSubview(Spinner)
        
        // Add Spinner View to Main View
        MainView.addSubview(SpinnerView)
    }
    
    /**
     Arguments: NULL
     Return: NULL
     Description:
         Hides and stops spinner animation
         Hides the view that has the spinner
     */
    func hideSpinner() {
        // Stop spinner animation
        Spinner.stopAnimating()
        // Hide the spinner
        Spinner.isHidden = true
        // Hide the view holding the spinner
        SpinnerView.isHidden = true
    }
    
    
    // MARK: - Text Field
    
    /**
     Arguments: UITextField
     Return: NULL
     Description:
         Sets LineGraphView when the text field is no longer selected
     */
    @IBAction func AmountTextFieldEditingDidEnd(_ sender: UITextField) {
        setGraphView()
    }
    /**
     Arguments: UITextField
     Return: NULL
     Description:
         Sets LineGraphView when the enter button is pressed on the keyboard
     */
    @IBAction func AmountTextFieldPrimaryActionTrigger(_ sender: UITextField) {
        setGraphView()
    }
    
    
    // MARK: - Picker
    
    /**
     Arguments: UIPickerView
     Return: NULL
     Description:
         Sets the number of pickers
     */
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    /**
     Argument: UIPickerView
     Argument: Int
     Return: Int
     Description:
         Sets how many options the pickerView will offer
     */
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return historyCurrency.count
    }
    /**
     Argument: UIPickerView
     Argument: titleForRow : Int
     Argument: forComponent: Int
     Return: String
     Description:
         Sets the values/title for each row on the pickerView
     */
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return historyCurrency[row]
    }
    /**
     Argument: UIPickerView
     Argument: didSelectRow : Int
     Argument: inComponent: Int
     Return: NULL
     Description:
         When the pickerView is moved to a different value/title the selectedCurrency1 or 2 is updated to reflect the selected value
         LineGraphView is updated to show the selected data
     */
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (pickerView.isEqual(currencyPicker1)) { // PickerView 1
            selectedCurrency1 = historyCurrency[row]
        } else if (pickerView.isEqual(currencyPicker2)) { // PickerView 2
            selectedCurrency2 = historyCurrency[row]
        }
        // When neither selectedCurrency values are empty set LineGraphView
        if (!selectedCurrency1.isEmpty && !selectedCurrency2.isEmpty) {
            self.setGraphView()
        }
    }
}
