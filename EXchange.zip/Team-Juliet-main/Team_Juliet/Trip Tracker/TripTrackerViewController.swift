//
//  TripTrackerViewController.swift
//  Team_Juliet
//
//  Created by Joshua Hernandez on 3/30/22.
//

import UIKit

class TripTrackerViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var tripTotal = 0.0
    
    var currencyCode: [String] = []
    var values: [Double] = []
    var selectedCurrency = 0.0
    
    @IBOutlet var totalAmountLabel: UILabel!
    @IBOutlet var amountSpentTextField: UITextField!
    @IBOutlet var addAmount: UIButton!
    
    @IBOutlet var currExchnageLabel: UILabel!
    @IBOutlet var currExchangePicker: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        currExchangePicker.delegate = self
        currExchangePicker.dataSource = self
        fetchJSON()
    }
    
    func calculateTrip() {
        if let textValue = amountSpentTextField.text {
            let amount = Double(textValue)
            tripTotal = tripTotal + (amount ?? 0.0)
        }
    }
    
    
    @IBAction func addAction(_ sender: UIButton) {
        calculateTrip()
        currExchnageLabel.text = String(format: "%0.2f", tripTotal * selectedCurrency)
        totalAmountLabel.text = String(format: "%0.2f", tripTotal)
        amountSpentTextField.text = "" 

    }
    
    @IBAction func subAction(_ sender: UIButton) {
        if let textValue = amountSpentTextField.text {
            let amount = Double(textValue)
            tripTotal = tripTotal - (amount ?? 0.0)
        }
        currExchnageLabel.text = String(format: "%0.2f", tripTotal * selectedCurrency)
        totalAmountLabel.text = String(format: "%0.2f", tripTotal)
        amountSpentTextField.text = ""
    }
    
    @IBAction func clearAction(_ sender: UIButton) {
        tripTotal = 0.0
        currExchnageLabel.text = String(format: "%0.2f", tripTotal * selectedCurrency)
        totalAmountLabel.text = String(format: "%0.2f", tripTotal)
        amountSpentTextField.text = ""
    }
    
    @objc func updateViews(input: Double) {
        guard let amountText = currExchnageLabel.text, let theAmountText = Double(amountText) else { return }
        if currExchnageLabel.text != "" {
            let theAmountText = selectedCurrency
            currExchnageLabel.text = String(format: "%.2f", theAmountText)
        }
        else if theAmountText == 0.00 {
            currExchnageLabel.text = String(format: "%.2f", "0.00")
        }
    }
    
    // MARK - Get JSON Data
    func fetchJSON() {
        guard let url = URL(string: "https://open.er-api.com/v6/latest/USD") else { return }
        URLSession.shared.dataTask(with:url) { (data, response, error) in
            
            // Error handling
            if error != nil {
                print(error!)
                return
            }
            
            // Unwrap the data
            guard let safeData = data else { return }
            
            // Decoce JSON data
            do {
                let results = try JSONDecoder().decode(ExchangeRates.self, from: safeData)
                self.currencyCode.append(contentsOf: results.rates.keys)
                self.values.append(contentsOf: results.rates.values)
                DispatchQueue.main.async {
                    self.currExchangePicker.reloadAllComponents()
                }
                
            } catch {
                print(error)
            }
        }
        .resume()
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return currencyCode.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return currencyCode[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedCurrency = values[row]
        updateViews(input: selectedCurrency)
    }

}
