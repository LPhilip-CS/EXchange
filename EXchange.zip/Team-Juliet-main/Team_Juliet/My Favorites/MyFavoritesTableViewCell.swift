//
//  MyFavoritesTableViewCell.swift
//  Team_Juliet
//
//  Created by Lijo Philip on 3/30/22.
//

import UIKit

class MyFavoritesTableViewCell: UITableViewCell {
    

    // Rendering a cell row in UITableView.
    @IBOutlet weak var myFavoritesFlagImage: UIImageView!
    @IBOutlet weak var myFavoritesLabel: UILabel!
    @IBOutlet weak var myFavoritesStar: UIButton!
    
    var currency : CurrencyModel?
    
    func configure(with currency: CurrencyModel, row: Int) {
        myFavoritesLabel.text = currency.name
        myFavoritesFlagImage.image = UIImage(named: currency.name)
        myFavoritesStar.tag = row
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    // Configure the view for the selected country.
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        
    }

}
