//
//  CurrencyModel.swift
//  Team_Juliet
//
//  Created by Ayren King on 4/11/22.
//

// Currency information model.
struct CurrencyModel {
    var name : String
    var billType : String
    var info : String
    var favorited : Bool = false
    
    init(name: String, billType: String, info: String, favorited : Bool? = false) {
        self.name = name
        self.billType = billType
        self.info = info
    }
}

 var currencies : [CurrencyModel] =
    [
        CurrencyModel(name: "United States Dollar - USD", billType: "USDBill", info: "The United States dollar (symbol: $; code: USD; also abbreviated US$ or U.S. Dollar, to distinguish it from other dollar-denominated currencies; referred to as the dollar, U.S. dollar, American dollar, or colloquially buck) is the official currency of the United States and its territories. The Coinage Act of 1792 introduced the U.S. dollar at par with the Spanish silver dollar, divided it into 100 cents, and authorized the minting of coins denominated in dollars and cents. U.S. banknotes are issued in the form of Federal Reserve Notes, popularly called greenbacks due to their predominantly green color."),
        CurrencyModel(name:"European Euro - EUR",billType: "EURBill", info: "The euro (symbol: €; code: EUR) is the official currency of 19 of the 27 member states of the European Union. This group of states is known as the eurozone or, officially, the euro area, and includes about 343 million citizens as of 2019. The euro, which is divided into 100 cents, is the second-largest and second-most traded currency in the international markets for the related different types of transactions after the United States dollar." ),
        CurrencyModel(name:"Japanese Yen - JPY", billType: "YENBill", info: "The yen (Japanese: 円, symbol: ¥; code: JPY; also abbreviated as JP¥) is the official currency of Japan. It is the third-most traded currency in the foreign exchange market, after the United States dollar (US$) and the euro. It is also widely used as a third reserve currency after the US dollar and the euro. The concept of the yen was a component of the late-19th century Meiji government's modernization program of Japan's economy, which postulated the pursuit of a uniform currency throughout the country, modeled after the European decimal currency system."),
        CurrencyModel(name:"Pound Sterling - GBP",billType: "GBPBill", info: "The pound sterling (symbol: £; ISO code: GBP), known in some contexts as the British pound, the pound, or sterling, is the official currency of the United Kingdom, Jersey, Guernsey, the Isle of Man, Gibraltar, South Georgia and the South Sandwich Islands, the British Antarctic Territory, and Tristan da Cunha. It is subdivided into 100 pence (singular: penny, abbreviated: p). The pound sterling is the oldest currency in continuous use." ),
        CurrencyModel(name:"Canadian Dollar - CAD", billType: "CADBill", info: "The Canadian dollar (symbol: $; code: CAD; French: dollar canadien) is the currency of Canada. It is abbreviated with the dollar sign $, or sometimes CA$, Can$ or C$ to distinguish it from other dollar-denominated currencies. It is divided into 100 cents (¢). Owing to the image of a common loon on its back, the dollar coin, and sometimes the unit of currency itself, are sometimes referred to as the loonie by English-speaking Canadians and foreign exchange traders and analysts."),
        CurrencyModel(name:"Indian Rupee - INR", billType: "INRBill", info: "The Indian rupee (symbol: ₹; code: INR) is the official currency of India. The rupee is subdivided into 100 paise (singular: paisa), though as of 2019, coins of denomination of 1 rupee is the lowest value in use. The issuance of the currency is controlled by the Reserve Bank of India. The Reserve Bank manages currency in India and derives its role in currency management on the basis of the Reserve Bank of India Act, 1934."),
        CurrencyModel(name:"South Korean Won - KRW",billType: "KRWBill", info: "The South Korean won, officially the Korean Republic won (Symbol: ₩; Code: KRW; Korean: 대한민국 원) is the official currency of South Korea. A single won is divided into 100 jeon, the monetary subunit. The jeon is no longer used for everyday transactions, and it appears only in foreign exchange rates. The currency is issued by the Bank of Korea, based in the capital city of Seoul." ),
        CurrencyModel(name:"Mexican Peso - MXN",billType: "MXNBill", info: "The Mexican peso (symbol: $; code: MXN) is the currency of Mexico. Modern peso and dollar currencies have a common origin in the 16th–19th century Spanish dollar, most continuing to use its sign, $. The current ISO 4217 code for the peso is MXN; prior to the 1993 revaluation, the code MXP was used. The peso is subdivided into 100 centavos, represented by ¢. The Mexican peso is the 15th most traded currency in the world" ),
        CurrencyModel(name:"Ukranian Hryvnia - UAH",billType: "UAHBill", info: "The hryvnia, hryvna, or sometimes gryvnya (/(hə)ˈrɪvniə/ (hə-)RIV-nee-ə; Ukrainian: гривня [ˈɦrɪu̯nʲɐ] (audio speaker iconlisten), abbr.: грн hrn; sign: ₴; code: UAH), has been the national currency of Ukraine since 2 September 1996. The hryvnia is subdivided into 100 kopiyok. It is named after a measure of weight used in medieval Kyivan Rus'. слава україні!" ),
        CurrencyModel(name:"Russian Ruble - RUB", billType: "RUBBill", info: "The Russian ruble or rouble (Russian: рубль rublʹ; symbol: ₽, руб; code: RUB) is the official currency of the Russian Federation. The ruble was the currency of the Russian Empire and of the Soviet Union (as the Soviet ruble). However, today only Russia, Belarus and Transnistria use currencies with the same name. путин отстой!"),
    ];
