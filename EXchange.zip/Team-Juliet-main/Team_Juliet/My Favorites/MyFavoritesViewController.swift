//
//  MyFavoritesViewController.swift
//  Team_Juliet
//
//  Created by Lijo Philip on 3/30/22.
//

import UIKit
import Foundation

class MyFavoritesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    var myCurrencies: [CurrencyModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        let userDefaults = UserDefaults.standard
        let favoritedCurrencies = userDefaults.object(forKey: "favoriteCurrencies") as? [String]
        
        myCurrencies = currencies
        
        if favoritedCurrencies != nil{
            for (index, currency) in myCurrencies.enumerated() {
                if favoritedCurrencies!.contains(currency.name) {
                    myCurrencies[index].favorited = true
                }
            }
        }
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.reloadData()
    }
    
    
    // Function to pass array data to the currency information VC.
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let currencyInformationViewController = storyboard?.instantiateViewController(identifier: "CurrencyInformationViewController") as? CurrencyInformationViewController {
            currencyInformationViewController.currencyName = myCurrencies[indexPath.row].name
            currencyInformationViewController.currencyImage = UIImage(named: myCurrencies[indexPath.row].billType)!
            currencyInformationViewController.currencyFlag = UIImage(named: myCurrencies[indexPath.row].name)!
            currencyInformationViewController.currencyInfo = myCurrencies[indexPath.row].info
            
            self.navigationController?.pushViewController(currencyInformationViewController, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myCurrencies.count
    }
    
    // Function to present country name, flag and favorites in each cell row in TableView.
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyFavoritesTableViewCell", for: indexPath) as! MyFavoritesTableViewCell
        cell.configure(with: myCurrencies[indexPath.row], row: indexPath.row)
        cell.myFavoritesStar.addTarget(self, action: #selector(updateFavorite(_:)), for: .touchUpInside)
        
        if myCurrencies[indexPath.row].favorited {
            cell.myFavoritesStar.setImage(UIImage(named: "star.png")?.withTintColor(.green), for: UIControl.State.normal)
        } else {
            cell.myFavoritesStar.setImage(UIImage(named: "star.png")?.withTintColor(.gray), for: UIControl.State.normal)
        }
        
        return cell
    }
    
    // Favorited currencies.
    @objc func updateFavorite(_ sender: UIButton) {
        myCurrencies[sender.tag].favorited = !myCurrencies[sender.tag].favorited
        let indexPath = IndexPath(row: sender.tag, section: 0)
        tableView.reloadRows(at: [indexPath], with: .automatic)
        
        
        if myCurrencies[sender.tag].favorited {
            let userDefaults = UserDefaults.standard
            var favoritedCurrencies: [String] = userDefaults.object(forKey: "favoriteCurrencies") as? [String] ?? []
            
            favoritedCurrencies.append(myCurrencies[sender.tag].name)
            
            userDefaults.set(favoritedCurrencies, forKey: "favoriteCurrencies")
        } else {
            let userDefaults = UserDefaults.standard
            var favoritedCurrencies: [String] = userDefaults.object(forKey: "favoriteCurrencies") as? [String] ?? []
            
            favoritedCurrencies.removeAll(where: {$0 == myCurrencies[sender.tag].name})
            userDefaults.set(favoritedCurrencies, forKey: "favoriteCurrencies")
        }
    }
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        if segue.identifier == "InfoSegue" {
//            let destination = segue.destination as? UIViewController, let index = tableView.indexPathForSelectedRow?.row {
//                currencyInformationViewController.currencyName = myCurrencies[indexPath.row].name
//                currencyInformationViewController.currencyImage = UIImage(named: myCurrencies[indexPath.row].billType)!
//                currencyInformationViewController.currencyFlag = UIImage(named: myCurrencies[indexPath.row].name)!
//                currencyInformationViewController.currencyInfo = myCurrencies[indexPath.row].info
//            }
//        }
        
        // Present name, images, and information in VC.
        if segue.identifier == "InfoSegue", let destination = segue.destination as? CurrencyInformationViewController, let index = tableView.indexPathForSelectedRow?.row
            {
                // Pass the data to the viewController
            destination.currencyName = myCurrencies[index].name
            destination.currencyImage = UIImage(named: myCurrencies[index].billType)!
            destination.currencyFlag = UIImage(named: myCurrencies[index].name)!
            destination.currencyInfo = myCurrencies[index].info
            }
        
    }
    
}

