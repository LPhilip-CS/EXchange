//
//  UserViewModel.swift
//  Team_Juliet
//
//  Created by Ayren King on 3/7/22.
//

import SwiftUI
import FirebaseAuth

class UserViewModel: ObservableObject {
    
    let auth = Auth.auth()
    
    @Published var signedIn = false
    
    var isSignedIn: Bool {
        return auth.currentUser != nil
    }
 
    @MainActor
    func signIn(email: String, password: String) async -> (User?) {
        do {
            let authDataResult = try await auth.signIn(withEmail: email, password: password)
            let user = authDataResult.user
            
            print("Signed in as user \(user.uid), with email: \(user.email ?? "") ")
            
            return user
        }
        catch {
            print("Error signing in: \(error)")
            return nil
        }
    }

    func signUp(email: String, password: String) async -> (User?) {
        do {
            let authDataResult = try await auth.createUser(withEmail: email, password: password)
            let user = authDataResult.user
            
            print("Created user \(user.uid), with email: \(user.email ?? "") ")
            
            return user
        }
        catch {
            print("Error creating user in: \(error)")
            return nil
        }
    }
    
    func signOut() {
        do {
            try auth.signOut()
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
    }
            
}
