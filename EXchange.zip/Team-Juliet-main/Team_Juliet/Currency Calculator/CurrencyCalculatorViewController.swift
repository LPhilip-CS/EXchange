//
//  CurrencyCalculatorViewController.swift
//  Team_Juliet
//
//  Created by Isabell Cook on 4/22/22.
//

import UIKit

class CurrencyCalculatorViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    // Struct used toparse json APi data
    struct CurrentExchangeRates: Codable {
        let rates: [String: Double]
    }
    
    // array pf currencies and their conversion rates to USD
    var currencyRates: [String: Double] = [:]

    /**
     String of currencies that the API provides history for
     */
    var Currencies: [String] = []
    
    // Currency selected by the picker selector and amount value selected
    var selectedCurrency1: String = ""
    var selectedCurrency2: String = ""
    var AmountMultiplied1: Double = 1
    var AmountMultiplied2: Double = 1

    // Label outlets
    @IBOutlet weak var CurrencyLabel2: UILabel!
    @IBOutlet weak var CurrencyLabel1: UILabel!
    @IBOutlet weak var ConvertedCurrencyLabel2: UILabel!
    @IBOutlet weak var CovertedCurrencyLabel1: UILabel!
    // UITextField outlets
    @IBOutlet weak var Amount1TextField: UITextField!
    @IBOutlet weak var Amount2TextField: UITextField!

    // UIPickerView outlets
    @IBOutlet weak var currencyPicker1: UIPickerView!
    @IBOutlet weak var currencyPicker2: UIPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        currencyPicker1.delegate = self
        currencyPicker1.dataSource = self
        currencyPicker2.delegate = self
        currencyPicker2.dataSource = self
        // Do any additional setup after loading the view.
        generateCurrentExchangeRates()
    }
    
    // MARK: - Currency API
    func generateCurrentExchangeRates() {
        guard let url = URL(string: "https://open.er-api.com/v6/latest/USD") else { return }
        URLSession.shared.dataTask(with:url) { (data, response, error) in
            
            var currencyCode: [String] = []
            var values: [Double] = []
            
            // Error handling
            if error != nil {
                print(error!)
                return
            }
            
            // Unwrap the data
            guard let safeData = data else { return }
            
            // Decoce JSON data
            do {
                let results = try JSONDecoder().decode(CurrentExchangeRates.self, from: safeData)
                currencyCode.append(contentsOf: results.rates.keys)
                values.append(contentsOf: results.rates.values)
                for (index, currency) in currencyCode.enumerated() {
                    self.currencyRates[currency] = values[index]
                }
                DispatchQueue.main.async {
                    self.Currencies = Array(self.currencyRates.keys)
                    self.Currencies.sort()
                    self.currencyPicker1.reloadAllComponents()
                    self.currencyPicker2.reloadAllComponents()

                }
            }catch {
                print(error)
            }
        }
        .resume()
    }
    
    // MARK: - Set Values
    
    func setValue1(){
        // Rate * amount
        CovertedCurrencyLabel1.text = String( (currencyRates[selectedCurrency1] ?? 1) * AmountMultiplied1)
    }
    
    func setValue2() {
        ConvertedCurrencyLabel2.text = String( (currencyRates[selectedCurrency2] ?? 1) * AmountMultiplied2)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    // MARK: - Text Field
    
    /**
     Arguments: UITextField
     Return: NULL
     Description:
         Sets LineGraphView when the text field is no longer selected
     */
    @IBAction func AmountTextFieldEditingDidEnd(_ sender: UITextField) {
        if (sender.isEqual(Amount1TextField)){
            print(Double(Amount1TextField.text!))
            AmountMultiplied1 = Double(Amount1TextField.text!)!
            setValue1()
        } else if (sender.isEqual(Amount2TextField)){
            print(Amount2TextField.text!)
            AmountMultiplied2 = Double(Amount2TextField.text!)!
            setValue2()
        }
        // DO something
    }
    /**
     Arguments: UITextField
     Return: NULL
     Description:
         Sets LineGraphView when the enter button is pressed on the keyboard
     */
    @IBAction func AmountTextFieldPrimaryActionTrigger(_ sender: UITextField) {
        if (sender.isEqual(Amount1TextField)){
            AmountMultiplied1 = Double(Amount1TextField.text ?? "1") ?? 1
            print(Double(Amount1TextField.text ?? "1"))
            setValue1()
        } else if (sender.isEqual(Amount2TextField)){
            AmountMultiplied2 = Double(Amount2TextField.text ?? "1") ?? 1
            print(Amount2TextField.text)
            setValue2()
        }
        // do something
    }
    
    
    // MARK: - Picker
    
    /**
     Arguments: UIPickerView
     Return: NULL
     Description:
         Sets the number of pickers
     */
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    /**
     Argument: UIPickerView
     Argument: Int
     Return: Int
     Description:
         Sets how many options the pickerView will offer
     */
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Currencies.count
    }
    /**
     Argument: UIPickerView
     Argument: titleForRow : Int
     Argument: forComponent: Int
     Return: String
     Description:
         Sets the values/title for each row on the pickerView
     */
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return Currencies[row]
    }
    /**
     Argument: UIPickerView
     Argument: didSelectRow : Int
     Argument: inComponent: Int
     Return: NULL
     Description:
         When the pickerView is moved to a different value/title the selectedCurrency1 or 2 is updated to reflect the selected value
         LineGraphView is updated to show the selected data
     */
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if (pickerView.isEqual(currencyPicker1)) { // PickerView 1
            CurrencyLabel1.text = Currencies[row]
            selectedCurrency1 = Currencies[row]
            setValue1()
        } else if (pickerView.isEqual(currencyPicker2)) { // PickerView 2
            CurrencyLabel2.text = Currencies[row]
            selectedCurrency2 = Currencies[row]
            setValue2()
        }
        
    }

}
